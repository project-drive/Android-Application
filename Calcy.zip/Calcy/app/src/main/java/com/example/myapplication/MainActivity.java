package com.example.myapplication;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.TextView;

import example.myapplication.R;


public class MainActivity extends AppCompatActivity {

    private Button one;
    private Button two;
    private Button three;
    private Button four;
    private Button five;
    private Button six;
    private Button seven;
    private Button eight;
    private Button nine;
    private Button zero;
    private Button add;
    private Button sub;
    private Button mul;
    private Button div;
    private Button eql;
    private Button clr;
    private TextView info;
    private TextView result;
    private final char ADDITION = '+';
    private final char SUBTRACTION = '-';
    private final char MULTIPLICATION = '*';
    private final char DIVISION = '/';
    private final char EQU = 0;
    private double val1 = Double.NaN;
    private double val2;
    private char ACTION;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setupUIViews();

        zero.setOnClickListener(new View.OnClickListener() {
            @Override
            public void Onclick(View v) {
                info.setText(info.getText().toString() + "0");
            }
        });
         one.setOnClickListener(new View.OnClickListener() {
        @Override
        public void Onclick(View v){
        info.setText(info.getText().toString() + "1");
    }
    });
         two.setOnClickListener(new View.OnClickListener()

    {
        @Override
        public void Onclick (View v){
        info.setText(info.getText().toString() + "2");
    }
    });
         three.setOnClickListener(new View.OnClickListener()

    {
        @Override
        public void Onclick (View v){
        info.setText(info.getText().toString() + "3");
    }
    });

         four.setOnClickListener(new View.OnClickListener()

    {
        @Override
        public void Onclick (View v){
        info.setText(info.getText().toString() + "4");
    }
    });
     five.setOnClickListener(new View.OnClickListener()

    {
        @Override
        public void Onclick (View v){
        info.setText(info.getText().toString() + "5");
    }
    });
     six.setOnClickListener(new View.OnClickListener()

    {
        @Override
        public void Onclick (View v){
        info.setText(info.getText().toString() + "6");
    }
    });
     seven.setOnClickListener(new View.OnClickListener()

    {
        @Override
        public void Onclick (View v){
        info.setText(info.getText().toString() + "7");
    }
    });
     eight.setOnClickListener(new View.OnClickListener()

    {
        @Override
        public void Onclick(View v){
        info.setText(info.getText().toString() + "8");
    }
    });
    nine.setOnClickListener(new View.OnClickListener() {
        @Override
        public void Onclick (View v){
        info.setText(info.getText().toString() + "9");
    }
    });
       add.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {

               ACTION = ADDITION;
               result.setText(String.valueOf(val1) + "+");
               info.setText(null);
           }
       });

        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ACTION = SUBTRACTION;
                result.setText(String.valueOf(val1) + "-");
                info.setText(null);
            }
        });
        mul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ACTION = MULTIPLICATION;
                result.setText(String.valueOf(val1) + "*");
                info.setText(null);
            }
        });
        div.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ACTION = DIVISION;
                result.setText(String.valueOf(val1) + "/");
                info.setText(null);
            }
        });

        eql.setOnClickListener(new View.OnClickListener() {
            @Override
             public void onClick (View v){
                compute();
                ACTION=EQU;
                result.setText(result.getText().toString() + String.valueOf(val2) + "=" + String.valueOf(val1));
                //5+4=9
                info.setText(null);
            }
        });


            clr.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v){
                if(info.getText().length()>0) {
                    CharSequence name = info.getTextClassifier().toString();
                    info.setText(((String) name).subSequence(0, name.length() - 1));
                }
                else{
                    val1=Double.NaN;
                    val2=Double.NaN;
                    info.setText(null);
                    result.setText(null);
                }
            }
        });
    }
     private void setupUIViews() {
            one = (Button) findViewById(R.id.BTN1);
            two = (Button) findViewById(R.id.BTN2);
            three = (Button) findViewById(R.id.BTN3);
            four = (Button) findViewById(R.id.BTN4);
            five = (Button) findViewById(R.id.BTN5);
            six = (Button) findViewById(R.id.BTN6);
            seven = (Button) findViewById(R.id.BTN7);
            eight = (Button) findViewById(R.id.BTN8);
            nine = (Button) findViewById(R.id.BTN9);
            zero = (Button) findViewById(R.id.BTN0);
            add = (Button) findViewById(R.id.BTNADD);
            sub = (Button) findViewById(R.id.BTNSUB);
            mul = (Button) findViewById(R.id.BTNMUL);
            div = (Button) findViewById(R.id.BTNDIV);
            eql = (Button) findViewById(R.id.BTNEQL);
            clr = (Button) findViewById(R.id.BTNCLR);
            info = (TextView) findViewById(R.id.TVCNTRL);
            result = (TextView) findViewById(R.id.TVRST);
        }
        private void compute();{
           if(!Double.isNaN(val1)) {
               val2=Double.parseDouble(info.getText().toString());

               switch (ACTION){
                   case ADDITION:
                       val1=val1+val2;
                       break;
                   case SUBTRACTION:
                       val1=val1-val2;
                       break;
                   case MULTIPLICATION:
                       val1=val1*val2;
                       break;
                   case DIVISION:
                       val1=val1*val2;
                       break;
                   case EQU:
                       break;
               }
           }
           else{
               val1=Double.parseDouble(info.getText().toString());
           }
        }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}



